<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>C++ Main Program</name>
    <message>
        <source>Add Hours and Minutes</source>
        <comment>Application Name</comment>
        <translation>Rechnen mit Stunden und Minuten</translation>
    </message>
</context>
<context>
    <name>Calculator</name>
    <message>
        <source>Overflow</source>
        <translation>Überlauf</translation>
    </message>
</context>
</TS>
