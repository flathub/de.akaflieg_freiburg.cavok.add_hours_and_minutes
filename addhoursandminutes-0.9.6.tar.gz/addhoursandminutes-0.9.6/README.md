# Add Hours and Minutes

**Add Hours and Minutes** is a simple calculator app that adds times given in hours
and minutes. It helps with the recording of machine running times, with the
addition of flight times in your pilots' flight log, or your driving times as a
truck driver.

- Simple, elegant and functional

- No advertisement, no commerical "pro" version

- Does not spy on you

- 100% Open Source

- Written without commercial interest
